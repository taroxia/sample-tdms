using SqlKata.Compilers;
using Microsoft.Extensions.Configuration;

namespace Infrastructure.Data;

public interface ISqlKataCompilerFactory
{
    Compiler CreateCompiler();
}

public class SqlKataCompilerFactory : ISqlKataCompilerFactory
{
    private readonly IConfiguration _configuration;
    private readonly string _provider;

    public SqlKataCompilerFactory(IConfiguration configuration)
    {
        _configuration = configuration;
        _provider = _configuration["DatabaseSettings:Provider"] ?? "PostgreSQL";
    }

    public Compiler CreateCompiler()
    {
        // 備考: DuckDBはPostgreSQLのSQLシンタックスに強くインスパイアされているため、
        // SqlKataにおいてはPostgresCompilerを共用することで安定したクエリ構築が可能です。
        return new PostgresCompiler();
    }
}