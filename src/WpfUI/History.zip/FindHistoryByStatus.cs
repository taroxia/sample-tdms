namespace WPFUI.Features.History.Queries;

/// <summary>
/// 特定のステータスで履歴を検索するクエリ要求（純粋なデータ構造）
/// </summary>
public sealed record FindHistoryByStatus(string Status);