using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace WPFUI.Core.Abstractions
{
    public interface IParquetStorageService
    {
        Task WriteColumnsAsync(string filePath, IReadOnlyDictionary<string, Array> columns, CancellationToken cancellationToken = default);
        Task<IReadOnlyDictionary<string, Array>> ReadColumnsAsync(string filePath, CancellationToken cancellationToken = default);
    }
}