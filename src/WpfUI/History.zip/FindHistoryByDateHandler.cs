using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Dapper;
using SqlKata;
using Infrastructure.Data;

namespace Infrastructure.Data.QueryHandlers;

public class FindHistoryByDateHandler
{
    private readonly IDbConnectionFactory _connectionFactory;
    private readonly ISqlKataCompilerFactory _compilerFactory;

    public FindHistoryByDateHandler(IDbConnectionFactory connectionFactory, ISqlKataCompilerFactory compilerFactory)
    {
        _connectionFactory = connectionFactory;
        _compilerFactory = compilerFactory;
    }

    public async Task<IEnumerable<dynamic>> HandleAsync(DateTime targetDate)
    {
        var query = new Query("Histories")
            .WhereDate("CreatedAt", "=", targetDate)
            .OrderByDesc("CreatedAt");

        var compiler = _compilerFactory.CreateCompiler();
        var compiled = compiler.Compile(query);

        await using var connection = _connectionFactory.CreateConnection();
        await connection.OpenAsync();

        return await connection.QueryAsync(compiled.Sql, compiled.NamedBindings);
    }
}