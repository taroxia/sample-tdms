using System.Data;
using System.Threading;
using System.Threading.Tasks;

namespace WPFUI.Core.Abstractions
{
    public interface IDbConnectionFactory
    {
        IDbConnection CreateConnection();
        Task<IDbConnection> CreateConnectionAsync(CancellationToken cancellationToken = default);
    }
}