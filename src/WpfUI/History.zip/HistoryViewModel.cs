using System;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Infrastructure.Data.QueryHandlers;
using WPFUI.Core.Domain.Types;
using WPFUI.Features.History.Queries;

namespace WPFUI.Features.History;

public partial class HistoryViewModel : ObservableObject
{
    private readonly FindHistoryByDateHandler _findByDateHandler;
    private readonly FindHistoryByStatusHandler _findByStatusHandler;

    [ObservableProperty]
    private DateTime _searchDate = DateTime.Today;

    [ObservableProperty]
    private string _searchStatus = "Completed";

    [ObservableProperty]
    private bool _isBusy;

    public ObservableCollection<HistoryRecord> Histories { get; } = new();

    public HistoryViewModel(
        FindHistoryByDateHandler findByDateHandler,
        FindHistoryByStatusHandler findByStatusHandler)
    {
        _findByDateHandler = findByDateHandler ?? throw new ArgumentNullException(nameof(findByDateHandler));
        _findByStatusHandler = findByStatusHandler ?? throw new ArgumentNullException(nameof(findByStatusHandler));
    }

    [RelayCommand]
    private async Task SearchByDateAsync()
    {
        if (IsBusy) return;
        IsBusy = true;

        try
        {
            Histories.Clear();
            var query = new FindHistoryByDate(SearchDate);
            
            // ハンドラの実行 (Infrastructure層へのデリゲート)
            var results = await _findByDateHandler.HandleAsync(query.TargetDate);
            
            foreach (var result in results)
            {
                Histories.Add(MapToRecord(result));
            }
        }
        finally
        {
            IsBusy = false;
        }
    }

    [RelayCommand]
    private async Task SearchByStatusAsync()
    {
        if (IsBusy) return;
        IsBusy = true;

        try
        {
            Histories.Clear();
            var query = new FindHistoryByStatus(SearchStatus);
            
            // ハンドラの実行 (Infrastructure層へのデリゲート)
            var results = await _findByStatusHandler.HandleAsync(query.Status);
            
            foreach (var result in results)
            {
                Histories.Add(MapToRecord(result));
            }
        }
        finally
        {
            IsBusy = false;
        }
    }

    /// <summary>
    /// dynamic型（Dapper結果）からドメインのRecordへ安全にマッピングします。
    /// DuckDBとPostgreSQLのドライバ間で生じる型差異（例：bigint/Int64 と int/Int32）をConvertで吸収します。
    /// </summary>
    private static HistoryRecord MapToRecord(dynamic result)
    {
        return new HistoryRecord
        {
            Id = Convert.ToInt32(result.Id),
            MeasurementDate = Convert.ToDateTime(result.MeasurementDate),
            Status = result.Status?.ToString() ?? string.Empty,
            TdmsFilePath = result.TdmsFilePath?.ToString() ?? string.Empty,
            ParquetFilePath = result.ParquetFilePath?.ToString() ?? string.Empty,
            Description = result.Description?.ToString() ?? string.Empty,
            CreatedAt = Convert.ToDateTime(result.CreatedAt)
        };
    }
}