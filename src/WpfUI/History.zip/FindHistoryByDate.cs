using System;

namespace WPFUI.Features.History.Queries;

/// <summary>
/// 特定の作成日で履歴を検索するクエリ要求（純粋なデータ構造）
/// </summary>
public sealed record FindHistoryByDate(DateTime TargetDate);