using System;
using System.Data.Common;
using Microsoft.Extensions.Configuration;
using Npgsql;
using DuckDB.NET.Data;

namespace Infrastructure.Data;

public interface IDbConnectionFactory
{
    DbConnection CreateConnection();
}

public class DbConnectionFactory : IDbConnectionFactory
{
    private readonly IConfiguration _configuration;
    private readonly string _provider;
    private readonly string _connectionString;

    public DbConnectionFactory(IConfiguration configuration)
    {
        _configuration = configuration;
        _provider = _configuration["DatabaseSettings:Provider"] ?? "PostgreSQL";
        _connectionString = _configuration.GetConnectionString("DefaultConnection") 
                            ?? throw new ArgumentNullException("Connection string is not configured.");
    }

    public DbConnection CreateConnection()
    {
        return _provider.ToLowerInvariant() switch
        {
            "postgresql" or "npgsql" => new NpgsqlConnection(_connectionString),
            "duckdb" => new DuckDBConnection(_connectionString),
            _ => throw new NotSupportedException($"Database provider '{_provider}' is not supported.")
        };
    }
}