using System.Collections.Generic;
using System.Threading.Tasks;
using Dapper;
using SqlKata;
using Infrastructure.Data;

namespace Infrastructure.Data.QueryHandlers;

public class FindHistoryByStatusHandler
{
    private readonly IDbConnectionFactory _connectionFactory;
    private readonly ISqlKataCompilerFactory _compilerFactory;

    public FindHistoryByStatusHandler(IDbConnectionFactory connectionFactory, ISqlKataCompilerFactory compilerFactory)
    {
        _connectionFactory = connectionFactory;
        _compilerFactory = compilerFactory;
    }

    public async Task<IEnumerable<dynamic>> HandleAsync(string status)
    {
        var query = new Query("Histories")
            .Where("Status", "=", status)
            .OrderByDesc("CreatedAt");

        var compiler = _compilerFactory.CreateCompiler();
        var compiled = compiler.Compile(query);

        await using var connection = _connectionFactory.CreateConnection();
        await connection.OpenAsync();

        return await connection.QueryAsync(compiled.Sql, compiled.NamedBindings);
    }
}