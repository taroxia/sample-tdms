using System;

namespace WPFUI.Core.Domain.Types
{
    public sealed record HistoryRecord
    {
        public int Id { get; init; }
        public DateTime MeasurementDate { get; init; }
        public string Status { get; init; } = string.Empty;
        public string TdmsFilePath { get; init; } = string.Empty;
        public string ParquetFilePath { get; init; } = string.Empty;
        public string Description { get; init; } = string.Empty;
        public DateTime CreatedAt { get; init; }
    }
}