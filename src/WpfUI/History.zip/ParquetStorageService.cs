using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using Parquet;
using Parquet.Serialization;

namespace Infrastructure.Persistence.Parquet;

public class ParquetStorageService<T> where T : new()
{
    /// <summary>
    /// レコードの書き込み（ReadOnlyMemoryを利用したメモリアロケーションの最適化）
    /// </summary>
    public async Task WriteAsync(ReadOnlyMemory<T> records, string filePath, CancellationToken cancellationToken = default)
    {
        // 確実な非同期リソース解放
        await using var fileStream = new FileStream(filePath, FileMode.Create, FileAccess.Write, FileShare.None, 4096, true);
        
        // V6仕様のオプション設定 (UseDictionaryEncoding は属性制御に移行したため削除)
        var options = new ParquetOptions 
        { 
            TreatByteArrayAsString = true 
        };

        // DataColumnを使用しないSerializerによる書き込み
        // ※ customMetadataは独自のフッター情報が不要なため省略
        await ParquetSerializer.SerializeAsync(
            records.ToArray(), 
            fileStream, 
            options, 
            cancellationToken);
    }

    /// <summary>
    /// レコードの読み込み（DeserializationResult<T>を用いた安全なデシリアライズ）
    /// </summary>
    public async Task<IReadOnlyList<T>> ReadAsync(string filePath, CancellationToken cancellationToken = default)
    {
        if (!File.Exists(filePath))
        {
            return Array.Empty<T>();
        }

        await using var fileStream = new FileStream(filePath, FileMode.Open, FileAccess.Read, FileShare.Read, 4096, true);
        
        var options = new ParquetOptions
        {
            TreatByteArrayAsString = true
        };

        // Parquet.Net v6準拠のデシリアライザ結果受け取り
        // ※ rowGroupIndexはファイル全体（全行グループ）を読み込むため省略
        DeserializationResult<T> result = await ParquetSerializer.DeserializeAsync<T>(
            fileStream, 
            options, 
            cancellationToken);
        
        return result.Data;
    }
}